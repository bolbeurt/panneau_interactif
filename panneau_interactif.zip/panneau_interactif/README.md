# acs-mvc

<h1>Squelette de base MVC</h1>

<strong>Pensez à modifier:</strong>

<ul>
<li>le .htaccess</li>
<li>le fichier ./app/config.php (Modifier les define pour l'accès à votre base de données)</li>
</ul>
