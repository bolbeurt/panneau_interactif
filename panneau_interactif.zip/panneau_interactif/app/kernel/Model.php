<?php

abstract class Model  {
	

}