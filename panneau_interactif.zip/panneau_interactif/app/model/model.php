<?php

class Model {
    
}